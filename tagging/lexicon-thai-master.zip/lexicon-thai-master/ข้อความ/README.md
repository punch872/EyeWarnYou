# Thai Sentiment Text

คลังข้อมูลสำหรับ Sentiment ภาษาไทย

โดย นาย วรรณพงษ์  ภัททิยไพบูลย์

thai text of positive and negative. 

ช่วยกรอกข้อมูลได้ที่ https://goo.gl/forms/7JccnQQ7cxefZRLs2



ฐานข้อมูลนี้ใช้[![Creative Commons License](https://i.creativecommons.org/l/by-sa/4.0/88x31.png)](https://creativecommons.org/licenses/by-sa/4.0/)
This work is licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-sa/4.0/).

กรุณาทำตาม Creative Commons Attribution-ShareAlike 4.0 International Public License



ฐานข้อมูลนี้และฐานข้อมูลอื่น ๆ ใน lexicon-thai ไม่มีส่วนเกี่ยวข้องกับภาครัฐและไม่มีสิ่งเกี่ยวข้องกับ Thailand 4.0 **ห้ามแอบอ้าง**