# คลังข้อมูล ประโยคแปลภาษาไทยและภาษาอังกฤษ

[![สัญญาอนุญาตของครีเอทีฟคอมมอนส์](https://i.creativecommons.org/l/by/3.0/th/88x31.png)]

licensed under [CC-BY 3.0](http://creativecommons.org/licenses/by/3.0/)

จัดทำโดย นาย วรรณพงษ์  ภัททิยไพบูลย์
