# Thai Synonym

Synonym for Thai lang.

https://github.com/wannaphongcom/synonym-crawler
