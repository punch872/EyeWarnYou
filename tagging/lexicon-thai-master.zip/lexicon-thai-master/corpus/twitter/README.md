﻿# Thai twitter corpus

[![สัญญาอนุญาตของครีเอทีฟคอมมอนส์](https://i.creativecommons.org/l/by-nc-sa/3.0/th/88x31.png)]

licensed under [CC-BY-NC-SA 3.0](http://creativecommons.org/licenses/by-nc-sa/3.0/)

โดย นาย วรรณพงษ์  ภัททิยไพบูลย์